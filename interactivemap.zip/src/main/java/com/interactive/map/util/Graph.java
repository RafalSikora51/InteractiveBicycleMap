package com.interactive.map.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.interactive.map.entity.Point;
import com.interactive.map.entity.Segment;
import com.interactive.map.repo.PointDAO;
import com.interactive.map.repo.SegmentDAO;

import ch.qos.logback.core.pattern.parser.Node;
import javassist.compiler.ast.Declarator;

public class Graph {

	@Autowired
	private PointDAO pointDAO;

	@Autowired
	private SegmentDAO segmentDAO;

	// Węzły pobrane z bazy
	public List<Point> nodes;

	// Mapa, w której zawiera się cały graf ( czyli wierzchołki - klucze i mapa :
	// sąsiedzi(wierzchołki) + łączące je krawędzie)
	public Map<Point, Map<Point, Segment>> adjacencyList;

	public Graph(List<Point> nodes) {
		this.nodes = nodes;
	}

	public Graph() {
		nodes = new ArrayList<>();
		adjacencyList = new HashMap<Point, Map<Point, Segment>>();

	}

	public List<Point> getNodes() {
		return nodes;
	}

	public void setNodes(List<Point> nodes) {
		this.nodes = nodes;
	}

	public void addNode(Point pointA) {

		nodes.add(pointA);

	}

	public Point getLowestDistanceNode(Map<Point, Map<Point, Segment>> unsettledMap) {

		Point lowestDistanceNode = null;

		double lowestDistance = Integer.MAX_VALUE;

		for (Point node : adjacencyList.keySet()) {

			for (Map<Point, Segment> adjacentPair : adjacencyList.values()) {

				List<Segment> nodeDistance = new ArrayList<>();
				nodeDistance = adjacentPair.values().stream().collect(Collectors.toList());
				System.out.println("test");
				for (int i = 1; i < nodeDistance.size(); i++) {
					System.out.println(nodeDistance.get(i).getLength());
					System.out.println("test");
					
					if(nodeDistance.get(i).getLength() < lowestDistance) {
						
						lowestDistance = nodeDistance.get(i).getLength();
					}

				
				}

				// System.out.print(lowestDistanceNode + " xx " + lowestDistance);

				System.out.println();
				System.out.println("tu tu");
			}
		}

		return lowestDistanceNode;

	}

	public void calculateMinimumDistance(Point evaluationNode, double edgeWeight, Point currentNode) {

		// double sourceDistance = sourceNodeMap.

	}

	public Graph calculateShortestPathFromSource(Graph graph, Point source) {

		Map<Point, Map<Point, Segment>> unsettledMap = new HashMap<>();

		Map<Point, Map<Point, Segment>> settledMap = new HashMap<>();

		unsettledMap.put(nodes.get(source.getId()), adjacencyList.get(nodes.get(source.getId())));

		while (unsettledMap.size() != 0) {

			Point currentNode = getLowestDistanceNode(unsettledMap);

			unsettledMap.remove(currentNode);

			for (Entry<Point, Segment> adjacencyPair : unsettledMap.get(currentNode).entrySet()) {

				Point adjacentNode = adjacencyPair.getKey();
				double edgeWeight = adjacencyPair.getValue().getLength();

				if (!settledMap.containsKey(adjacentNode)) {

					calculateMinimumDistance(adjacentNode, edgeWeight, currentNode);
					// unsettledMap.put(key, value)
				}

			}

		}

		System.out.println(unsettledMap);

		unsettledMap.get(nodes.get(source.getId())).values().iterator().next().setLength(0);

		System.out.println("Po zmianie dlugosci segmentu: " + unsettledMap);

		return graph;
	}

}
