package com.interactive.map.util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.interactive.map.entity.Point;
import com.interactive.map.entity.Segment;

public class Node {

	Point point;

	private List<Node> shortestPath = new LinkedList<>();

	private Integer distance = Integer.MAX_VALUE;

	Map<Node, Integer> adjacentNodes = new HashMap<>();

	public void addDestination(Node destination, int distance) {
		adjacentNodes.put(destination, distance);

	}

	public Node(Point point) {
		this.point = point;

	}

	public Map<Node, Integer> getAdjacentNodes() {
		return adjacentNodes;
	}

	public void setAdjacentNodes(Map<Node, Integer> adjacentNodes) {
		this.adjacentNodes = adjacentNodes;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public List<Node> getShortestPath() {
		return shortestPath;
	}

	public void setShortestPath(LinkedList<Node> shortestPath) {
		this.shortestPath = shortestPath;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adjacentNodes == null) ? 0 : adjacentNodes.hashCode());
		result = prime * result + ((distance == null) ? 0 : distance.hashCode());
		result = prime * result + ((point == null) ? 0 : point.hashCode());
		return result;
	}


	@Override
	public String toString() {
		return "Node [point=" + point + ", shortestPath=" + shortestPath + ", distance=" + distance + ", adjacentNodes="
				+ adjacentNodes + "]";
	}
	
	
	
	

}
