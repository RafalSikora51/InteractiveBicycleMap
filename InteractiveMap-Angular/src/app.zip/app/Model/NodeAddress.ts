export interface NodeAddress {
    id: number;
    address: string;
}