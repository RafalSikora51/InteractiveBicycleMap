export interface Marker {
    lat: number;
    lng: number;
}
